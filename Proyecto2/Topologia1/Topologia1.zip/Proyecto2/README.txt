Project: 'Proyecto2' created on 2021-11-07
Author: John Doe <john.doe@example.com>

No project description was given